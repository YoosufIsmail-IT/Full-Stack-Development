import Header from '@/components/header'
import Footer from '@/components/footer'
import Link from 'next/link'
import { Heart, Activity, Microscope, AlertCircle, Pill, Smile, Brain, Bone } from 'lucide-react'

const services = [
  {
    icon: Heart,
    title: 'General Consultation',
    description: 'Comprehensive health consultations with our experienced general practitioners for all your medical concerns.'
  },
  {
    icon: Activity,
    title: 'Cardiology',
    description: 'Specialized cardiac care including heart disease diagnosis, treatment, and preventive cardiology services.'
  },
  {
    icon: Microscope,
    title: 'Laboratory Services',
    description: 'State-of-the-art laboratory testing including blood work, pathology, and advanced diagnostic tests.'
  },
  {
    icon: AlertCircle,
    title: 'Emergency Care',
    description: '24/7 emergency medical services with trained staff ready to handle urgent medical conditions.'
  },
  {
    icon: Pill,
    title: 'Pharmacy Services',
    description: 'On-site pharmacy with comprehensive medication services and drug counseling.'
  },
  {
    icon: Smile,
    title: 'Dental Care',
    description: 'Professional dental services including checkups, cleanings, and preventive oral health care.'
  },
  {
    icon: Brain,
    title: 'Neurology',
    description: 'Expert neurological care for conditions affecting the brain, nerves, and spinal cord.'
  },
  {
    icon: Bone,
    title: 'Orthopedics',
    description: 'Specialized treatment for bone, joint, and musculoskeletal disorders.'
  },
]

export default function Services() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-primary to-secondary text-primary-foreground py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Medical Services</h1>
            <p className="text-lg opacity-90 max-w-2xl">
              Comprehensive healthcare services designed to meet your medical needs with excellence and professionalism.
            </p>
          </div>
        </section>

        {/* Services Grid */}
        <section className="py-16 md:py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {services.map((service, idx) => {
                const Icon = service.icon
                return (
                  <div 
                    key={idx}
                    className="bg-muted rounded-xl p-8 hover:shadow-lg transition"
                  >
                    <div className="w-14 h-14 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                      <Icon className="text-primary" size={28} />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-3">{service.title}</h3>
                    <p className="text-muted-foreground">{service.description}</p>
                  </div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Service Features */}
        <section className="bg-muted py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-12 text-center">Why Choose Our Services</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">24/7</div>
                <p className="text-muted-foreground">Round-the-clock availability for emergencies</p>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">Expert</div>
                <p className="text-muted-foreground">Board-certified and experienced specialists</p>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">Modern</div>
                <p className="text-muted-foreground">Advanced medical equipment and technology</p>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">Caring</div>
                <p className="text-muted-foreground">Patient-centered approach to healthcare</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-primary text-primary-foreground py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Schedule Your Service Today</h2>
            <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
              Book an appointment with our healthcare professionals
            </p>
            <Link 
              href="/appointment"
              className="inline-block px-8 py-3 bg-white text-primary font-semibold rounded-lg hover:opacity-90 transition"
            >
              Book Now
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
