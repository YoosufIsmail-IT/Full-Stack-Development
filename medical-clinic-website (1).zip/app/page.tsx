import Header from '@/components/header'
import Footer from '@/components/footer'
import Link from 'next/link'
import { ArrowRight, Heart, Users, Award } from 'lucide-react'

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-primary to-secondary text-primary-foreground py-20 md:py-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                  Your Health, Our Priority
                </h1>
                <p className="text-lg opacity-90 mb-8">
                  Experience world-class medical care with our team of experienced physicians and modern facilities dedicated to your well-being.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link 
                    href="/appointment"
                    className="inline-flex items-center justify-center px-6 py-3 bg-white text-primary font-semibold rounded-lg hover:opacity-90 transition"
                  >
                    Book Appointment
                    <ArrowRight className="ml-2" size={20} />
                  </Link>
                  <Link 
                    href="/services"
                    className="inline-flex items-center justify-center px-6 py-3 border-2 border-white rounded-lg hover:bg-white hover:bg-opacity-10 transition"
                  >
                    Explore Services
                  </Link>
                </div>
              </div>
              <div className="relative">
                <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-8 border border-white border-opacity-20">
                  <div className="bg-white bg-opacity-20 rounded-xl aspect-video flex items-center justify-center">
                    <Heart size={64} className="text-white opacity-50" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 md:py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="inline-block w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mb-4">
                  <Users className="text-primary" size={32} />
                </div>
                <h3 className="text-3xl font-bold text-foreground mb-2">10,000+</h3>
                <p className="text-muted-foreground">Patients Treated</p>
              </div>
              <div className="text-center">
                <div className="inline-block w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mb-4">
                  <Award className="text-primary" size={32} />
                </div>
                <h3 className="text-3xl font-bold text-foreground mb-2">50+</h3>
                <p className="text-muted-foreground">Experienced Doctors</p>
              </div>
              <div className="text-center">
                <div className="inline-block w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mb-4">
                  <Heart className="text-primary" size={32} />
                </div>
                <h3 className="text-3xl font-bold text-foreground mb-2">20+</h3>
                <p className="text-muted-foreground">Medical Services</p>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Services */}
        <section className="py-16 md:py-24 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Services</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                We offer comprehensive medical services with a focus on patient care and excellence
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { title: 'General Consultation', desc: 'Expert consultation for all your health concerns' },
                { title: 'Specialist Care', desc: 'Visit our specialists for complex medical conditions' },
                { title: 'Preventive Health', desc: 'Regular checkups and preventive medicine programs' },
                { title: 'Diagnostics', desc: 'Advanced laboratory and imaging services' },
                { title: 'Emergency Care', desc: '24/7 emergency medical services available' },
                { title: 'Wellness Programs', desc: 'Comprehensive health and wellness initiatives' },
              ].map((service, idx) => (
                <div 
                  key={idx}
                  className="bg-white rounded-xl p-6 hover:shadow-lg transition"
                >
                  <div className="w-12 h-12 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                    <Heart className="text-primary" size={24} />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">{service.title}</h3>
                  <p className="text-muted-foreground text-sm">{service.desc}</p>
                </div>
              ))}
            </div>

            <div className="text-center mt-12">
              <Link 
                href="/services"
                className="inline-flex items-center px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition font-semibold"
              >
                View All Services
                <ArrowRight className="ml-2" size={20} />
              </Link>
            </div>
          </div>
        </section>

        {/* Featured Doctors */}
        <section className="py-16 md:py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Meet Our Doctors</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Our team of highly qualified and experienced medical professionals
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { name: 'Dr. Sarah Johnson', specialty: 'General Medicine', experience: '15+ years' },
                { name: 'Dr. Michael Chen', specialty: 'Cardiology', experience: '12+ years' },
                { name: 'Dr. Emily Rodriguez', specialty: 'Pediatrics', experience: '10+ years' },
              ].map((doctor, idx) => (
                <div 
                  key={idx}
                  className="bg-muted rounded-xl overflow-hidden hover:shadow-lg transition"
                >
                  <div className="bg-primary bg-opacity-10 h-48 flex items-center justify-center">
                    <Users size={64} className="text-primary opacity-50" />
                  </div>
                  <div className="p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-1">{doctor.name}</h3>
                    <p className="text-primary font-medium mb-2">{doctor.specialty}</p>
                    <p className="text-sm text-muted-foreground">{doctor.experience}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center mt-12">
              <Link 
                href="/doctors"
                className="inline-flex items-center px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition font-semibold"
              >
                View All Doctors
                <ArrowRight className="ml-2" size={20} />
              </Link>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-primary text-primary-foreground py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Book Your Appointment?</h2>
            <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
              Schedule your visit with one of our experienced doctors today
            </p>
            <Link 
              href="/appointment"
              className="inline-block px-8 py-3 bg-white text-primary font-semibold rounded-lg hover:opacity-90 transition"
            >
              Book Now
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
