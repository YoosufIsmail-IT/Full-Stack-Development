import Header from '@/components/header'
import Footer from '@/components/footer'
import Link from 'next/link'
import { Users, Award } from 'lucide-react'

const doctors = [
  {
    name: 'Dr. Sarah Johnson',
    specialty: 'General Medicine',
    experience: '15+ years',
    qualification: 'MD, Board Certified in Internal Medicine',
    description: 'Specializes in comprehensive patient care and preventive medicine with a focus on patient education.'
  },
  {
    name: 'Dr. Michael Chen',
    specialty: 'Cardiology',
    experience: '12+ years',
    qualification: 'MD, Cardiology Specialist, Interventional Cardiology',
    description: 'Expert in heart disease management, cardiac interventions, and cardiovascular risk reduction.'
  },
  {
    name: 'Dr. Emily Rodriguez',
    specialty: 'Pediatrics',
    experience: '10+ years',
    qualification: 'MD, Board Certified Pediatrician',
    description: 'Dedicated to providing compassionate care for children from infancy through adolescence.'
  },
  {
    name: 'Dr. James Wilson',
    specialty: 'Orthopedic Surgery',
    experience: '14+ years',
    qualification: 'MD, Orthopedic Surgery, Sports Medicine',
    description: 'Specializes in surgical and non-surgical treatment of musculoskeletal disorders.'
  },
  {
    name: 'Dr. Lisa Patel',
    specialty: 'Neurology',
    experience: '13+ years',
    qualification: 'MD, Board Certified Neurologist',
    description: 'Expertise in neurological disorders including migraines, epilepsy, and neurodegenerative diseases.'
  },
  {
    name: 'Dr. Robert Taylor',
    specialty: 'Gastroenterology',
    experience: '16+ years',
    qualification: 'MD, Gastroenterology, Hepatology',
    description: 'Specialist in digestive system disorders with expertise in endoscopic procedures.'
  },
]

export default function Doctors() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-primary to-secondary text-primary-foreground py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Medical Team</h1>
            <p className="text-lg opacity-90 max-w-2xl">
              Meet our experienced and dedicated healthcare professionals committed to your well-being.
            </p>
          </div>
        </section>

        {/* Doctors Grid */}
        <section className="py-16 md:py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {doctors.map((doctor, idx) => (
                <div 
                  key={idx}
                  className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition"
                >
                  <div className="bg-primary bg-opacity-10 h-40 flex items-center justify-center">
                    <Users size={80} className="text-primary opacity-50" />
                  </div>
                  <div className="p-8">
                    <h3 className="text-2xl font-bold text-foreground mb-2">{doctor.name}</h3>
                    <p className="text-primary font-semibold mb-1">{doctor.specialty}</p>
                    <div className="flex items-center gap-2 text-muted-foreground text-sm mb-4">
                      <Award size={16} />
                      <span>{doctor.experience} experience</span>
                    </div>
                    <p className="text-sm font-medium text-muted-foreground mb-4">{doctor.qualification}</p>
                    <p className="text-muted-foreground leading-relaxed">{doctor.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Specializations */}
        <section className="bg-muted py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-12 text-center">Medical Specializations</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
              {[
                'General Medicine',
                'Cardiology',
                'Pediatrics',
                'Orthopedic Surgery',
                'Neurology',
                'Gastroenterology',
                'Dentistry',
                'Emergency Medicine',
                'Laboratory Services'
              ].map((specialty, idx) => (
                <div 
                  key={idx}
                  className="bg-white rounded-lg p-4 text-center border border-gray-200 hover:border-primary transition"
                >
                  <p className="font-semibold text-foreground">{specialty}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-primary text-primary-foreground py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Book an Appointment with Our Doctors</h2>
            <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
              Schedule your consultation today with our expert medical professionals
            </p>
            <Link 
              href="/appointment"
              className="inline-block px-8 py-3 bg-white text-primary font-semibold rounded-lg hover:opacity-90 transition"
            >
              Book Appointment
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
