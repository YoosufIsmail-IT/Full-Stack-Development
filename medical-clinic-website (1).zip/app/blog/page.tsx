import Header from '@/components/header'
import Footer from '@/components/footer'
import Link from 'next/link'
import { ArrowRight, Calendar, User } from 'lucide-react'

const blogPosts = [
  {
    id: 1,
    title: '10 Tips for a Healthier Lifestyle',
    excerpt: 'Discover practical and evidence-based strategies to improve your overall health and well-being.',
    date: 'March 15, 2024',
    author: 'Dr. Sarah Johnson',
    category: 'Wellness'
  },
  {
    id: 2,
    title: 'Understanding Heart Disease: Prevention and Management',
    excerpt: 'Learn about the risk factors of heart disease and how to prevent cardiovascular complications.',
    date: 'March 10, 2024',
    author: 'Dr. Michael Chen',
    category: 'Cardiology'
  },
  {
    id: 3,
    title: 'Pediatric Nutrition Guide for Growing Children',
    excerpt: 'A comprehensive guide to ensuring your children receive proper nutrition for optimal growth and development.',
    date: 'March 5, 2024',
    author: 'Dr. Emily Rodriguez',
    category: 'Pediatrics'
  },
  {
    id: 4,
    title: 'Managing Stress and Mental Health',
    excerpt: 'Practical techniques to manage stress and maintain mental health in today\'s fast-paced world.',
    date: 'February 28, 2024',
    author: 'Dr. Lisa Patel',
    category: 'Mental Health'
  },
  {
    id: 5,
    title: 'Exercise and Joint Health: What You Need to Know',
    excerpt: 'Discover the right exercises to maintain healthy joints and prevent orthopedic problems.',
    date: 'February 20, 2024',
    author: 'Dr. James Wilson',
    category: 'Orthopedics'
  },
  {
    id: 6,
    title: 'Digestive Health: Common Issues and Solutions',
    excerpt: 'Understanding common digestive problems and lifestyle changes that can improve gut health.',
    date: 'February 15, 2024',
    author: 'Dr. Robert Taylor',
    category: 'Gastroenterology'
  },
]

export default function Blog() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-primary to-secondary text-primary-foreground py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Health & Wellness Blog</h1>
            <p className="text-lg opacity-90 max-w-2xl">
              Expert insights, health tips, and medical information to help you live a healthier life.
            </p>
          </div>
        </section>

        {/* Featured Post */}
        <section className="py-16 md:py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-muted rounded-xl overflow-hidden">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center p-8 md:p-12">
                <div className="bg-primary bg-opacity-10 h-64 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <Calendar size={48} className="text-primary opacity-50 mx-auto mb-2" />
                    <p className="text-muted-foreground">Featured Article</p>
                  </div>
                </div>
                <div>
                  <span className="inline-block px-3 py-1 bg-primary bg-opacity-10 text-primary rounded-full text-sm font-semibold mb-4">
                    Featured
                  </span>
                  <h2 className="text-3xl font-bold text-foreground mb-4">
                    {blogPosts[0].title}
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    {blogPosts[0].excerpt}
                  </p>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-6">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <User size={16} />
                      <span>{blogPosts[0].author}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar size={16} />
                      <span>{blogPosts[0].date}</span>
                    </div>
                  </div>
                  <Link 
                    href={`/blog/${blogPosts[0].id}`}
                    className="inline-flex items-center px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition font-semibold"
                  >
                    Read More
                    <ArrowRight className="ml-2" size={18} />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Blog Grid */}
        <section className="py-16 md:py-24 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-foreground mb-12">Latest Articles</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogPosts.slice(1).map((post) => (
                <article 
                  key={post.id}
                  className="bg-white rounded-xl overflow-hidden hover:shadow-lg transition"
                >
                  <div className="bg-primary bg-opacity-5 h-40 flex items-center justify-center">
                    <Calendar size={48} className="text-primary opacity-30" />
                  </div>
                  <div className="p-6">
                    <span className="inline-block px-3 py-1 bg-primary bg-opacity-10 text-primary rounded-full text-xs font-semibold mb-3">
                      {post.category}
                    </span>
                    <h3 className="text-lg font-bold text-foreground mb-2 line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                      {post.excerpt}
                    </p>
                    <div className="space-y-2 text-xs text-muted-foreground mb-4">
                      <div className="flex items-center gap-2">
                        <User size={14} />
                        <span>{post.author}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar size={14} />
                        <span>{post.date}</span>
                      </div>
                    </div>
                    <Link 
                      href={`/blog/${post.id}`}
                      className="text-primary font-semibold hover:opacity-80 transition flex items-center gap-1"
                    >
                      Read More
                      <ArrowRight size={16} />
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* Newsletter */}
        <section className="bg-primary text-primary-foreground py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Stay Updated with Health Tips</h2>
            <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
              Subscribe to our newsletter for the latest health insights and wellness tips
            </p>
            <form className="max-w-md mx-auto flex gap-2">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="flex-1 px-4 py-3 rounded-lg text-foreground"
                required
              />
              <button 
                type="submit"
                className="px-6 py-3 bg-white text-primary font-semibold rounded-lg hover:opacity-90 transition"
              >
                Subscribe
              </button>
            </form>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
