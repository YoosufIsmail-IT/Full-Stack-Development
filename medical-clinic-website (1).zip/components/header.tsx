'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Menu, X } from 'lucide-react'

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">M</span>
          </div>
          <span className="font-bold text-lg text-foreground hidden sm:inline">MediCare</span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          <Link href="/" className="text-foreground hover:text-primary transition">Home</Link>
          <Link href="/services" className="text-foreground hover:text-primary transition">Services</Link>
          <Link href="/doctors" className="text-foreground hover:text-primary transition">Doctors</Link>
          <Link href="/blog" className="text-foreground hover:text-primary transition">Blog</Link>
          <Link href="/contact" className="text-foreground hover:text-primary transition">Contact</Link>
          <Link 
            href="/appointment"
            className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition"
          >
            Book Appointment
          </Link>
        </div>

        <button
          className="md:hidden p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {mobileMenuOpen && (
        <div className="md:hidden border-t border-gray-200 bg-white">
          <div className="flex flex-col gap-4 p-4">
            <Link href="/" className="text-foreground hover:text-primary transition">Home</Link>
            <Link href="/services" className="text-foreground hover:text-primary transition">Services</Link>
            <Link href="/doctors" className="text-foreground hover:text-primary transition">Doctors</Link>
            <Link href="/blog" className="text-foreground hover:text-primary transition">Blog</Link>
            <Link href="/contact" className="text-foreground hover:text-primary transition">Contact</Link>
            <Link 
              href="/appointment"
              className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition text-center"
            >
              Book Appointment
            </Link>
          </div>
        </div>
      )}
    </header>
  )
}
